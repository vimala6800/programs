﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RegistrationLogin
{
    public partial class Registration : System.Web.UI.Page
    {
        
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "insert into reg values(@name,@mobile,@email,@password,@DOB,@sex,@education,@location)";
            SqlCommand cmd= new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@name", name.Text);
            cmd.Parameters.AddWithValue("@mobile",mobile.Text);
            cmd.Parameters.AddWithValue("@email", email.Text);
            cmd.Parameters.AddWithValue("@password",password.Text);
            ;
            DateTime dob1 = dob.SelectedDate;
            cmd.Parameters.AddWithValue("@DOB", dob.SelectedDate);
            string gen = gender.Text;
            cmd.Parameters.AddWithValue("@sex", gen);
            string edu=ug.Text;
            cmd.Parameters.AddWithValue("@education", edu);
            string location = loc.Text;
            cmd.Parameters.AddWithValue("@location",location);
            con.Open();
            int a=cmd.ExecuteNonQuery();
            if(a>0)
            {
                ClientScript.RegisterStartupScript(typeof(Page), "script", "alert('Registration Sucessful for users:" + name.Text + "and password is:" + password.Text + "');", true);
                ClearControls();
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('Registration Failed')</script>");
            }
            con.Close();

        }
        void ClearControls()
        {
            name.Text=mobile.Text=email.Text=password.Text= "";
        }

        protected void name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}