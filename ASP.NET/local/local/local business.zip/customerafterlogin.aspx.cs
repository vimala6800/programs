﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace local
{
    public partial class customerlogin : System.Web.UI.Page
    {
        string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            Showall();
        }
        void Showall()
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "SELECT users.name,email,mobile,city, location, address, zipcode, services.servicename as servicename,description,status from  users CROSS JOIN services  where users.roleid=3";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            GridView1.DataSource = data;
            GridView1.DataBind();
        }


        void servicename()
        {
            SqlConnection con = new SqlConnection(cs);
            string query = "SELECT users.name,email,mobile,city, location, address, zipcode, services.servicename as servicename,description,status from  users CROSS JOIN services  where users.roleid=3 and services.servicename='" + TextBox1.Text.Trim() + "';";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable data = new DataTable();
            sda.Fill(data);
            GridView1.DataSource = data;
            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Showall();
            servicename();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("landingpage.aspx");

            /*string cs = ConfigurationManager.ConnectionStrings["dbcs"].ConnectionString;
            SqlConnection con = null;
            try
            {
                string query = "seelct id,name from serviceprovider and ";
                SqlCommand cmd=new SqlCommand(query, con);
                con.Open();
                SqlDataReader Dr = cmd.ExecuteReader();
                while(Dr.Read())
                {
                    Console.WriteLine();
                }
            }catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                con.Close();
            }
            string query1 = "insert into servicebooking values(@date,@serviceid,@userid,@description,@status,@serviceproviderid,@providerdescription)";
             SqlConnection con = null;
            SqlCommand cmd1=new SqlCommand(query1, con);

          */
        }
    }
}
