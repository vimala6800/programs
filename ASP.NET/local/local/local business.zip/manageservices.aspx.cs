﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Net.Mime.MediaTypeNames;

namespace local
{
    public partial class manageservices : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void LinkButton1_click(object sender, EventArgs e)
        {
            SqlDataSource1.InsertParameters["name"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("nametemplate")).Text;
            SqlDataSource1.InsertParameters["description"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("desctemplate")).Text;
            SqlDataSource1.InsertParameters["status"].DefaultValue = ((TextBox)GridView1.FooterRow.FindControl("statustemplate")).Text;
            int a = SqlDataSource1.Insert();
            if (a > 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('Insertion Sucessful')</script>");
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "scripts", "<script>alert('Insertion Failed')</script>");

            }
        }

    }
}