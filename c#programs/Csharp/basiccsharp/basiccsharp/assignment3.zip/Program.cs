﻿using basiccsharp;

internal class Program
{
    private static void Main(string[] args)
    {

        /* loops.whileloop();
             loops.forloop();
             loops.forloopbreak();
             operators.arithmeticoperator();
             simpleinterest.time();
         conversion.kms();
         printingtable.table();
         user.eligibletovote();
         convert.currency();
         convert.currency1();
         array.arrays();

         Console.WriteLine("constructor");
         constructor customer = new constructor(1, "a", "abc@gmail.com", "8765367897", "banglore");
         Console.WriteLine(customer.info());
         customer.country = "india";
         Console.WriteLine("country"+customer.country);
         customer.zipcode = 560062;
         Console.WriteLine("zipcode"+customer.zipcode);
         constructor customer1 = new constructor(2, "b", "gbj@gmail.com", "6785367897", "ap");
         Console.WriteLine(customer1.info());
         customer1.country = "india";
         Console.WriteLine("country" + customer1.country);
         customer1.zipcode = 565738;
         Console.WriteLine("zipcode" + customer1.zipcode);
         product p1=new product();
         p1.code = 1;
         p1.name = "mobile";
         p1.description = "samsung";
         p1.supplier = "xyz";
         p1.price = 1130;
         Car car1 = new Car();
         car1.name = "SUV";
         car1.model = "Creta";
         car1.make = "Hundai";
         car1.price = 17000000;
         car1.ac = "Kenstar";
         car1.start();
         car1.move();
         car1.move();
         Console.WriteLine(car1.info());
         car1.stop();*/

        account ac1 = new account(456654, "vimala", "vimala@gmail.com", "4563798765", 2500f);
     
        Console.WriteLine(ac1.info());
        
        Console.WriteLine("available balance is:" + ac1.Depositamount(456654, 6797f));
        Console.WriteLine("Remaing balance is:" + ac1.Withdrawamount(456654, 500f));
        Console.WriteLine(ac1.Bal());
        account ac2 = new account(654653, "sai", "sai@gmail.com", "9863797765", 3000f);
        account ac3 = new account(765438, "madhuri", "madhuri@gmail.com", "8563798765", 2000f);
        Console.WriteLine(ac2.info());
        Console.WriteLine(ac3.info());
    }
}