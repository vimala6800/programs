﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace basiccsharp
{
    internal class operators
    {
        public static void arithmeticoperator()
        {
            Console.WriteLine("arithmetic operators");
            int n1 = 50;
            int n2 = 30;
            int result = n1 + n2;
            Console.WriteLine("n1 + n2 " + result);
            result = n1 - n2;
            Console.WriteLine("n1 - n2 " + result);
            result = n1 *n2;
            Console.WriteLine("n1 * n2 " + result);
            result = n1 / n2;
            Console.WriteLine("n1 / n2 " + result);
        }
        
    }
    
}
